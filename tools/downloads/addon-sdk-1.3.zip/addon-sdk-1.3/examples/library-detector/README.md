This is a port to the SDK of the
[Library Detector add-on](https://addons.mozilla.org/en-US/firefox/addon/library-detector/).
The original Library Detector is written by
[Paul Bakaus](http://paulbakaus.com/) and made available under the
[MIT License](http://www.opensource.org/licenses/mit-license.php).

It only recognizes a subset of the libraries recognized by the original,
just to keep the SDK download package size and on-disk footprint as small
as possible.
