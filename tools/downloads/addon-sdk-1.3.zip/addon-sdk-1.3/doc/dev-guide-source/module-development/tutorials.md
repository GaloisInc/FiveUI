# Module Development > Tutorials #
<br>
## Programming Guides ##

### [Low-Level Module Best Practices](dev-guide/module-development/best-practices.html) ###

### [Chrome Authority](dev-guide/module-development/chrome.html) ###

### [XPI Generation](dev-guide/module-development/xpi.html) ###

### [Out-of-Process Add-ons](dev-guide/module-development/e10s.html) ###
