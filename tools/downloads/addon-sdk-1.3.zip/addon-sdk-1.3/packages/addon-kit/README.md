The addon-kit package provides high-level APIs for add-on developers.
Most of the needs of most add-on developers should be served by the modules
found here. Modules in this packages don't require any special privileges to
run.

The modules in the addon-kit package are relatively stable. We intend to add
new APIs here and extend existing ones, but will avoid making incompatible
changes to them unless absolutely necessary.
