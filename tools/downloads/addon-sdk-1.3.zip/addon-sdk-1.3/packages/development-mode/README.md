This package contains a program that pings a local server for
information about other programs to run. If the same program
is requested more than once, it is first unloaded before being run
again. This can be very useful for developing add-ons without
having to restart the parent application.

In the future, functionality will be added that allows developers to
debug and profile their programs' behavior.
