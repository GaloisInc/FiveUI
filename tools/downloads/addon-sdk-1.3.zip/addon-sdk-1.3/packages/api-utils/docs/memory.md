The `memory` module provides a concrete default implementation for the SDK's
`memory` global. For documentation on the `memory` global, see the
[Globals](dev-guide/module-development/globals.html) reference.
