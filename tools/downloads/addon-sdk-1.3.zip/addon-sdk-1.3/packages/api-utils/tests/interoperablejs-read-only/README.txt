This is an svn export of just the 'compliance' directory of the
interoperablejs project on Google Code:

  http://code.google.com/p/interoperablejs/
