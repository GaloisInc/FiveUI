var test = require('test');
var b = require('b');
test.print('DONE', 'info');
