define('modules/green', ['./color'], function (color) {
  return {
    name: 'green',
    parentType: color.type
  };
});
