define(['./color'], function (color) {
  return {
    name: 'orange',
    parentType: color.type
  };
});
