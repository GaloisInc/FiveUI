define({
  type: 'color'
});
