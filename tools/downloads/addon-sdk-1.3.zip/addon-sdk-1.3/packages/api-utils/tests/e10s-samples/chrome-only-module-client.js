exports.main = function() {
  require("e10s-samples/chrome-only-module");
};
