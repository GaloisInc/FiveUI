throw new Error("This code should never be loaded in the Firefox process!");
