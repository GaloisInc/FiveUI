exports.main = function() {
  throw new Error("alas");
};
