This module contains the bulk of the test harness setup and execution
implementation.
