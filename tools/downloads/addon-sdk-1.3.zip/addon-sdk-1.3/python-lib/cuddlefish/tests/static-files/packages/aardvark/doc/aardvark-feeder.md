The `aardvark-feeder` module simplifies feeding aardvarks.

<api name="feed">
@function
  Feed the aardvark.
@param food {string}
  The food.  Aardvarks will eat anything.
</api>
