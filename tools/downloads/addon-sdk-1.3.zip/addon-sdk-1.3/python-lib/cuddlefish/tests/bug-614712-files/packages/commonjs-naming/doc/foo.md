I am documentation for foo.
