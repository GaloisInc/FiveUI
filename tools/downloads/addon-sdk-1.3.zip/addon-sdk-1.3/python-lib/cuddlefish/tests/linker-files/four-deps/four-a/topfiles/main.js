exports.main = 42;
