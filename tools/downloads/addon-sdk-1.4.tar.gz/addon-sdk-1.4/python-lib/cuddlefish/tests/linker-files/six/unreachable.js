exports.main = "I am outside lib/ and cannot be reached, yet";
