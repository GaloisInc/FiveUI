exports.testThing = function(test) {
  test.assertEqual(2, 1 + 1);
};
