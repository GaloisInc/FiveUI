// This file contains XPCOM code that bootstraps an SDK-based add-on
// by loading its harness-options.json, registering all its resource
// directories, executing its loader, and then executing its program's
// main() function.
