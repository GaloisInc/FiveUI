"use strict";
exports.frozen = Object.freeze({});
exports.sealed = Object.seal({});
exports.inextensible = Object.preventExtensions({});
