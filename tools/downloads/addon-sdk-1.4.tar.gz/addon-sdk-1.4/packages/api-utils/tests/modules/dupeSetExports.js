define({name: "dupeSetExports"});

// so this should cause a failure
module.setExports("no no no");
