define(['./badSecond'], function (badSecond) {
  return {
    name: 'badFirst'
  };
});
