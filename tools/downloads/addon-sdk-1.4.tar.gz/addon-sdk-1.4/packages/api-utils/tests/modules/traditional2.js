exports.name = 'traditional2';
exports.traditional1Name = require('./traditional1').name;
