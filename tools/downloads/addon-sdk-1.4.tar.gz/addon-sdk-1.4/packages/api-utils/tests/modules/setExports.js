module.setExports(5);
