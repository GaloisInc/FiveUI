define('modules/add', function () {
  return function (a, b) {
    return a + b;
  };
});
