var first = require('./badFirst');

exports.name = 'badSecond';
exports.badFirstName = first.name;
