`cuddlefish` is the name of the SDK's module loader. It builds on
`securable-module` to provide many SDK-specific globals such as `console`
and `memory`.

This module still needs to be documented.
