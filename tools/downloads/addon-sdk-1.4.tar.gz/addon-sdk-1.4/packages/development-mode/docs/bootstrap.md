This module contains functionality that allows a program to
"bootstrap" other programs: that is, set up a runtime
environment for them and execute them.

At present, the functions defined by this module are
implementation-specific and subject to change.
