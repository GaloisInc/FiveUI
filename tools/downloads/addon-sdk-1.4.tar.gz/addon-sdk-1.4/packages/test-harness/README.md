<span class="aside">
For more information on testing in the Add-on SDK, see the
[Reusable Modules](dev-guide/addon-development/implementing-reusable-module.html)
tutorial.
</span>

This package contains a program that finds and runs tests. It is
automatically used whenever the `cfx test` command is executed.
