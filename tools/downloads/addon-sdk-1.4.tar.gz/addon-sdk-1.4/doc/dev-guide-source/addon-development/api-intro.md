# Introducing the APIs #

### [Common Idioms](dev-guide/addon-development/api-idioms.html) ###
An introduction to idioms used throughout the SDK.

### [API Overview](dev-guide/addon-development/api-modules.html) ###
A quick introduction to the modules provided in the
[`addon-kit`](packages/addon-kit/addon-kit.html) package.
